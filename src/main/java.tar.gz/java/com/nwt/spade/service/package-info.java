/**
 * Service layer beans.
 */
package com.nwt.spade.service;
