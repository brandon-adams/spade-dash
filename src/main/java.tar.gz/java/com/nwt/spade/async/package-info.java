/**
 * Async helpers.
 */
package com.nwt.spade.async;
