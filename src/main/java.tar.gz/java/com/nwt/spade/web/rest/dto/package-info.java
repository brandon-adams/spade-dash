/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package com.nwt.spade.web.rest.dto;
