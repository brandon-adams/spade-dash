/**
 * Spring MVC REST controllers.
 */
package com.nwt.spade.web.rest;
