package com.nwt.spade.web.rest;

public class MesosService {
	
	

}
