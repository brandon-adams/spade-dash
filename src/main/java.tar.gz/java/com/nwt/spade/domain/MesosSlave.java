package com.nwt.spade.domain;

public class MesosSlave {
	
	private String hostname;
	private String id;
	private double totalCpus;
	private double usedCpus;
	private int totalMem;
	private int usedMem;
	

}
