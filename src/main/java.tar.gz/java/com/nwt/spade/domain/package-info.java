/**
 * JPA domain objects.
 */
package com.nwt.spade.domain;
