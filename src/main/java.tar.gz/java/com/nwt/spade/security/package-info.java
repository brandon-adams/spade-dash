/**
 * Spring Security configuration.
 */
package com.nwt.spade.security;
