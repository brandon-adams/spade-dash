/**
 * 
 */
/**
 * @author badams
 *
 */
package com.nwt.spade.exceptions;