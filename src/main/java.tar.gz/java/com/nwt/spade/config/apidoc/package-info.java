/**
 * Swagger api specific code.
 */
package com.nwt.spade.config.apidoc;