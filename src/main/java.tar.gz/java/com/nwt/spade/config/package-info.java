/**
 * Spring Framework configuration files.
 */
package com.nwt.spade.config;
