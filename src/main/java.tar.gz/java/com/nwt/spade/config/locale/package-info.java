/**
 * Locale specific code.
 */
package com.nwt.spade.config.locale;
